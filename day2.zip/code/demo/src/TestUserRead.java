import com.google.gdata.client.douban.DoubanService;
import com.google.gdata.data.Link;
import com.google.gdata.data.douban.Attribute;
import com.google.gdata.data.douban.CollectionEntry;
import com.google.gdata.data.douban.CollectionFeed;
import com.google.gdata.data.douban.Subject;
import com.google.gdata.data.douban.Tag;
import com.google.gdata.data.douban.UserEntry;
import com.google.gdata.data.extensions.Rating;


public class TestUserRead {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		//1.����ȥ��������һ��api key secret. 
		String apiKey = "0c51c1ba21ad8cfd24f5452e6508a6f7";
		String secret = "359e16e5e5c62b6e";

		DoubanService myService = new DoubanService("����С���", apiKey,
				secret);
		myService.setAccessToken("9644556d2ba3cabdc2cd004782eb6037", "c78f514836b98fed");
		UserEntry ue = myService.getAuthorizedUser();
		String uid = ue.getUid();
		// ���Ȼ�ȡ�û��� �����ռ�����Ϣ 
		CollectionFeed  feeds =	myService.getUserCollections(uid, "book", null, null, 1, 1);
		//��ȡ�û��ղؼ�������ľ������Ŀ��Ϣ 
		for (CollectionEntry ce : feeds.getEntries()) {
//			System.out.println("id is " + ce.getId());
//		     String title =  ce.getTitle().getPlainText();
//			if (!ce.getAuthors().isEmpty()) {
//				System.out.println("author name is : "
//						+ ce.getAuthors().get(0).getName());
//				System.out.println("author URI is : "
//						+ ce.getAuthors().get(0).getUri());
//			}
//			System.out.println("status is " + ce.getStatus().getContent());

			printSubjectEntry(ce.getSubjectEntry());

//			Rating rating = ce.getRating();
//			if (rating != null)
//				System.out.println("max is " + rating.getMax() + " min is "
//						+ rating.getMin() + " value is " + rating.getValue()
//						+ " numRaters is " + rating.getNumRaters() + " average is "
//						+ rating.getAverage());
//			System.out.println("Tags:");
//			for (Tag tag : ce.getTags()) {
//				System.out.println(tag.getName());
//			}
		}
	}
	private static void printSubjectEntry(Subject se) {

		if (se == null)
			return;
		if (se.getSummary() != null)
			System.out.println("summary is " + se.getSummary().getPlainText());
		System.out.println("author is " + se.getAuthors().get(0).getName());
		String title =  se.getTitle().getPlainText();
		System.out.println(title );
		StringBuilder sb = new StringBuilder();
		for (Attribute attr : se.getAttributes()) {
			if("author".equals(attr.getName())){
				sb.append(attr.getContent());
				sb.append("/");
			}else if("publisher".equals(attr.getName())){
				sb.append(attr.getContent());
				sb.append("/");
			}else if("pubdate".equals(attr.getName())){
				sb.append(attr.getContent());
				sb.append("/");
			}else if("isbn10".equals(attr.getName())){
				sb.append(attr.getContent());
				sb.append("/");
			}
		}
		System.out.println(sb.toString());

		Rating rating = se.getRating();
		if (rating != null)
			System.out.println("max is " + rating.getMax() + " min is "
					+ rating.getMin() + " numRaters is "
					+ rating.getNumRaters() + " average is "
					+ rating.getAverage());
		for (Link link : se.getLinks()) {
			//System.out.println("  " + link.getRel() + " is " + link.getHref());
			if("image".equals(link.getRel())){
				System.out.println(link.getHref());
			}
		}
		System.out.println("********************");
	}
}
