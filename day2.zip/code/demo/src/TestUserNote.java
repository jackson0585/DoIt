import com.google.gdata.client.douban.DoubanService;
import com.google.gdata.data.TextContent;
import com.google.gdata.data.douban.Attribute;
import com.google.gdata.data.douban.NoteEntry;
import com.google.gdata.data.douban.NoteFeed;
import com.google.gdata.data.douban.UserEntry;


public class TestUserNote {

	/**
	 * @param args
	 */
	public static void main(String[] args)  throws Exception{
		//1.����ȥ��������һ��api key secret. 
		String apiKey = "0c51c1ba21ad8cfd24f5452e6508a6f7";
		String secret = "359e16e5e5c62b6e";

		DoubanService myService = new DoubanService("����С���", apiKey,
				secret);
		myService.setAccessToken("9644556d2ba3cabdc2cd004782eb6037", "c78f514836b98fed");
		UserEntry ue = myService.getAuthorizedUser();
		String uid = ue.getUid();
		// ���Ȼ�ȡ�û��� �����ռ�����Ϣ 
		NoteFeed  noteFeed = myService.getUserNotes(uid, 1, 10);
		for(NoteEntry ne: noteFeed.getEntries()) {
			printNoteEntry(ne);
		}
	}
	private static void printNoteEntry(NoteEntry noteEntry) {

		if(noteEntry.getContent() != null)
			System.out.println("content is "
				+ ((TextContent) noteEntry.getContent()).getContent().getPlainText());
		

		System.out
				.println("title is " + noteEntry.getTitle().getPlainText());

		for (Attribute attr : noteEntry.getAttributes()) {
			System.out.println(attr.getName() + " : " + attr.getContent());
		}
		System.out.println(noteEntry.getPublished().toString());
		
	}

}
