import com.google.gdata.client.douban.DoubanService;
import com.google.gdata.data.Link;
import com.google.gdata.data.TextContent;
import com.google.gdata.data.douban.UserEntry;


public class TestUserEntry {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		//1.����ȥ��������һ��api key secret. 
		String apiKey = "0c51c1ba21ad8cfd24f5452e6508a6f7";
		String secret = "359e16e5e5c62b6e";

		DoubanService myService = new DoubanService("����С���", apiKey,
				secret);
		myService.setAccessToken("9644556d2ba3cabdc2cd004782eb6037", "c78f514836b98fed");
		UserEntry ue = myService.getAuthorizedUser();
		String name = ue.getTitle().getPlainText();
		System.out.println(name);
		System.out.println(ue.getLocation());
		System.out.println(((TextContent) ue.getContent()).getContent().getPlainText());
		for (Link link : ue.getLinks()) {
			//System.out.println("  " + link.getRel() + " is " + link.getHref());
			if("icon".equals(link.getRel())){
				System.out.println(link.getHref());
			}
		}
		
	}

}
