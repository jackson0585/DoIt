package cn.itcast.douban;

import java.io.IOException;

import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.util.ServiceException;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class NewNoteActivity extends BaseActivity implements OnClickListener {
    EditText 	EditTextTitle;
    EditText  EditTextContent;
    Button btnSave,btnCancle;
    RadioButton rb1,rb2,rb3;
    CheckBox cb;
    ProgressDialog pd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		setContentView(R.layout.note_edit);
		pd = new ProgressDialog(this);
		
		super.onCreate(savedInstanceState);
	}

	@Override
	public void setupView() {
		EditTextTitle = (EditText) this.findViewById(R.id.EditTextTitle);
		EditTextContent = (EditText) this.findViewById(R.id.EditTextContent);
		btnSave = (Button) this.findViewById(R.id.btnSave);
		btnCancle = (Button) this.findViewById(R.id.btnCancel);
		rb1 = (RadioButton) this.findViewById(R.id.rb_private);
		rb2 = (RadioButton) this.findViewById(R.id.rb_friend);
		rb3 = (RadioButton) this.findViewById(R.id.rb_public);
		cb = (CheckBox) this.findViewById(R.id.cb_can_reply);

	}

	@Override
	public void setListener() {
		btnSave.setOnClickListener(this);
		btnCancle.setOnClickListener(this);

	}

	@Override
	public void fillData() {
		
		
		

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnCancel:
			
			finish();
			
			break;

		case R.id.btnSave:
			final String title = EditTextTitle.getText().toString();
			final String content = EditTextContent.getText().toString();
			String auth = null;
			if( rb1.isChecked()){
				auth = "private";
			}else if ( rb2.isChecked()){
				auth = "friend";
			}else {
				auth = "public";
			}
			String can_reply =null;
			if(cb.isChecked()){
				can_reply="yes";
			}else{
				can_reply ="no";
			}
			new AsyncTask<String, Void, Boolean>(){

				@Override
				protected Boolean doInBackground(String... params) {
					try {
						myService.createNote(new PlainTextConstruct(title), new PlainTextConstruct(content), params[0], params[1]);
						return true;
					} catch (Exception e) {
						return false;
					}
				}

				@Override
				protected void onPreExecute() {
					super.onPreExecute();
					pd.show();
				}

				@Override
				protected void onPostExecute(Boolean result) {
					// TODO Auto-generated method stub
					super.onPostExecute(result);
					pd.dismiss();
					if(result){
						setResult(200);
						finish();

					}else{
						showToast("�����ռ�ʧ��");
					}
				}
				
				
				
				
			}.execute(auth,can_reply);
			break;

		}
		
	}

}
