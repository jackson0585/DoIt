package cn.itcast.douban;

import java.io.IOException;

import cn.itcast.douban.util.LoadImageAsynTask;
import cn.itcast.douban.util.LoadImageAsynTask.LoadImageAsynTaskCallback;

import com.google.gdata.data.Link;
import com.google.gdata.data.TextContent;
import com.google.gdata.data.douban.UserEntry;
import com.google.gdata.util.ServiceException;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyInfoActivity extends BaseActivity implements OnClickListener {
	private TextView tv_name;
	private TextView tv_location;
	private TextView tv_info;
	private ImageView iv_icon;
	String name ;
	String location ;
	String content ;
	String iconurl;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		//��֤��������contentview Ȼ����ȥ���ø���ķ���
		setContentView(R.layout.my_info);
		super.onCreate(savedInstanceState);
		setupView();
		setListener();
		fillData();
		
	}

	@Override
	public void setupView() {
		tv_name= (TextView) this.findViewById(R.id.txtUserName);
		tv_location= (TextView) this.findViewById(R.id.txtUserAddress);
		tv_info= (TextView) this.findViewById(R.id.txtUserDescription);
		iv_icon = (ImageView)this.findViewById(R.id.imgUser);
		mRelativeLoading = (RelativeLayout) this.findViewById(R.id.loading);
		mTextViewTitle = (TextView) this.findViewById(R.id.myTitle);
		mImageBack = (ImageButton)this.findViewById(R.id.back_button);
	}

	@Override
	public void setListener() {
		mImageBack.setOnClickListener(this);

	}

	@Override
	public void fillData() {

		
		new AsyncTask<Void, Void, Void>() {

			
			//onPreExecute ���첽����ִ��֮ǰ���õķ��� 
			// ���������߳������ 
			// ��ʼ��ui�Ĳ���
			@Override
			protected void onPreExecute() {
				showLoading();
				super.onPreExecute();
			}
			// onPostExecute ���첽����(��̨����)ִ��֮����õķ��� 
			// ������ui�߳��� , 
			// 
			@Override
			protected void onPostExecute(Void result) {
				hideLoading();
				super.onPostExecute(result);
				tv_info.setText(content);
				tv_location.setText(location);
				tv_name.setText(name);
				//�����û���ͷ�� 
				LoadImageAsynTask task = new LoadImageAsynTask(new LoadImageAsynTaskCallback() {
					
					public void beforeLoadImage() {
						iv_icon.setImageResource(R.drawable.ic_launcher);
						
					}
					
					public void afterLoadImage(Bitmap bitmap) {
						if (bitmap!=null) {
							iv_icon.setImageBitmap(bitmap);
						}else{
							iv_icon.setImageResource(R.drawable.ic_launcher);
						}
						
					}
				});
				task.execute(iconurl);
				
				
			}
			// doInBackground ��ִ̨�е����� 
			// ����������һ�����̵߳��� 
			@Override
			protected Void doInBackground(Void... params) {
				// ִ�к�ʱ�Ĳ��� 
				try {
					UserEntry ue = myService.getAuthorizedUser();
					 name = ue.getTitle().getPlainText();
					 location = ue.getLocation();
					 content = ((TextContent) ue.getContent()).getContent().getPlainText();
						for (Link link : ue.getLinks()) {
							if("icon".equals(link.getRel())){
								iconurl = link.getHref();
							}
						}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
			}
		}.execute();
		
	}


	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back_button:
			finish();
			break;

		}
		
	}

}
