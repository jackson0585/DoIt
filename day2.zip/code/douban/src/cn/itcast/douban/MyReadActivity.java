package cn.itcast.douban;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gdata.data.Link;
import com.google.gdata.data.douban.Attribute;
import com.google.gdata.data.douban.CollectionEntry;
import com.google.gdata.data.douban.CollectionFeed;
import com.google.gdata.data.douban.Subject;
import com.google.gdata.data.douban.SubjectEntry;
import com.google.gdata.data.douban.UserEntry;
import com.google.gdata.data.extensions.Rating;
import com.google.gdata.util.ServiceException;

import cn.itcast.douban.domain.Book;
import cn.itcast.douban.util.LoadImageAsynTask;
import cn.itcast.douban.util.LoadImageAsynTask.LoadImageAsynTaskCallback;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyReadActivity extends BaseActivity implements OnItemClickListener {
	private ListView subjectlist;
	MyReadAdapter adapter;
	// Map<String,Bitmap> iconCache;
	Map<String, SoftReference<Bitmap>> iconCache;
	int startindex; // ��ʼ��ȡ���ݵ�id
	int count;
	int max = 20;
	boolean isloading = false;
	IntentFilter filter;
	KillReceiver receiver ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.subject);
		super.onCreate(savedInstanceState);
		startindex = 1;
		count = 5;
		// ��ʼ���ڴ滺��
		iconCache = new HashMap<String, SoftReference<Bitmap>>();
		
	}

	@Override
	public void setupView() {
		mRelativeLoading = (RelativeLayout) this.findViewById(R.id.loading);
		subjectlist = (ListView) this.findViewById(R.id.subjectlist);
		 filter = new IntentFilter();
		filter.addAction("kill_activity_action");
		 receiver = new KillReceiver();
		this.registerReceiver(receiver, filter);
	}

	@Override
	public void setListener() {
		subjectlist.setOnItemClickListener(this);
		subjectlist.setOnScrollListener(new OnScrollListener() {

			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
				case OnScrollListener.SCROLL_STATE_IDLE:
					// �����ǰ����״̬Ϊ��ֹ״̬
					// ����listview�������һ���û��ɼ�����Ŀ ���� ����listview������������������һ����Ŀ
					// ��ȡlistview�����һ���û��ɼ���Ŀ��λ��
					int positon = view.getLastVisiblePosition();
					System.out.println("���һ���ɼ���Ŀ��λ�� " + positon);
					int totalcount = adapter.getCount();
					System.out.println("listview ��Ŀ����Ŀ " + totalcount);
					if (positon == (totalcount - 1)) {// ������ǰ�����϶��������·�
						// ��ȡ���������
						startindex = startindex + count;
						if (startindex > max) {
							showToast("�����Ѿ����ص������Ŀ");
							return;
						}
						if (isloading) {
							return;
						}
						fillData();
					}

					break;

				}

			}

			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {

			}
		});
	}

	@Override
	public void fillData() {
		// ͨ���첽���� ��ȡ���� Ȼ����ʾ��������
		new AsyncTask<Void, Void, List<Book>>() {

			@Override
			protected void onPreExecute() {
				showLoading();
				isloading = true;
				super.onPreExecute();
			}

			@Override
			protected void onPostExecute(List<Book> result) {
				hideLoading();

				super.onPostExecute(result);
				if (result != null) {
					if (adapter == null) {
						adapter = new MyReadAdapter(result);
						subjectlist.setAdapter(adapter);
					} else {
						// ���»�ȡ�������� �ӵ�listview����������������
						// ֪ͨ�����������
						adapter.addMoreBook(result);
						// ֪ͨ������������������
						adapter.notifyDataSetChanged();
					}

				} else {
					showToast("��ȡ����ʧ��");
				}
				isloading = false;
			}

			@Override
			protected List<Book> doInBackground(Void... params) {
				try {
					UserEntry ue = myService.getAuthorizedUser();
					String uid = ue.getUid();
					// ���Ȼ�ȡ�û��� �����ռ�����Ϣ
					CollectionFeed feeds = myService.getUserCollections(uid,
							"book", null, null, startindex, count);
					List<Book> books = new ArrayList<Book>();
					for (CollectionEntry ce : feeds.getEntries()) {
						Subject se = ce.getSubjectEntry();

						if (se != null) {
							Book book = new Book();
							String title = se.getTitle().getPlainText();
							book.setName(title);
							StringBuilder sb = new StringBuilder();
							for (Attribute attr : se.getAttributes()) {
								if ("author".equals(attr.getName())) {
									sb.append(attr.getContent());
									sb.append("/");
								} else if ("publisher".equals(attr.getName())) {
									sb.append(attr.getContent());
									sb.append("/");
								} else if ("pubdate".equals(attr.getName())) {
									sb.append(attr.getContent());
									sb.append("/");
								} else if ("isbn10".equals(attr.getName())) {
									sb.append(attr.getContent());
									sb.append("/");
								}
							}
							book.setDescription(sb.toString());

							Rating rating = se.getRating();
							if (rating != null) {
								book.setRating(rating.getAverage());

							}
							for (Link link : se.getLinks()) {
								if ("image".equals(link.getRel())) {
									book.setBookurl(link.getHref());
								}
							}
							books.add(book);
						}

					}
					return books;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
		}.execute();
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {

	}

	private class MyReadAdapter extends BaseAdapter {

		private List<Book> books;

		public MyReadAdapter(List<Book> books) {
			this.books = books;
		}

		public void addMoreBook(List<Book> books) {
			for (Book book : books) {
				this.books.add(book);
			}
		}

		public int getCount() {

			return books.size();
		}

		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return books.get(position);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = View.inflate(MyReadActivity.this, R.layout.book_item,
					null);
			final ImageView iv_book = (ImageView) view
					.findViewById(R.id.book_img);
			RatingBar rb = (RatingBar) view.findViewById(R.id.ratingbar);
			TextView tv_title = (TextView) view.findViewById(R.id.book_title);
			TextView tv_description = (TextView) view
					.findViewById(R.id.book_description);
			Book book = books.get(position);
			if (book.getRating() != 0) {
				rb.setRating(book.getRating());
			} else {
				rb.setVisibility(View.INVISIBLE);
			}
			tv_description.setText(book.getDescription());
			tv_title.setText(book.getName());
			// �ж� ͼƬ�Ƿ���sd���ϴ���

			String iconpath = book.getBookurl();
			final String iconname = iconpath.substring(
					iconpath.lastIndexOf("/") + 1, iconpath.length());
			/*
			 * File file = new File("/sdcard/" + iconname); if (file.exists()) {
			 * iv_book.setImageURI(Uri.fromFile(file));
			 * System.out.println("ʹ��sd������"); } else {
			 */

			if (iconCache.containsKey(iconname)) {
				SoftReference<Bitmap> softref = iconCache.get(iconname);
				if (softref != null) {
					Bitmap bitmap = softref.get();
					if (bitmap != null) {
						System.out.println("ʹ���ڴ滺�� ");
						iv_book.setImageBitmap(bitmap);
					} else {
						loadimage(iv_book, book, iconname);
					}

				}

			} else {

				loadimage(iv_book, book, iconname);
			}
			return view;
		}

		private void loadimage(final ImageView iv_book, Book book,
				final String iconname) {
			LoadImageAsynTask task = new LoadImageAsynTask(
					new LoadImageAsynTaskCallback() {
						public void beforeLoadImage() {

							iv_book.setImageResource(R.drawable.book);
						}

						public void afterLoadImage(Bitmap bitmap) {
							if (bitmap != null) {
								System.out.println("���ط�����ͼƬ");
								iv_book.setImageBitmap(bitmap);
								/*
								 * // ��bitmap��ŵ�sd���� try { File file = new
								 * File("/sdcard/" + iconname); FileOutputStream
								 * stream = new FileOutputStream( file);
								 * bitmap.compress(CompressFormat.JPEG, 100,
								 * stream); } catch (Exception e) {
								 * e.printStackTrace(); }
								 */
								// ��ͼƬ��ŵ��ڴ滺������
								iconCache.put(iconname,
										new SoftReference<Bitmap>(bitmap));

							} else {
								iv_book.setImageResource(R.drawable.book);
							}

						}
					});
			task.execute(book.getBookurl());
		}

	}

	private class KillReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context context, Intent intent) {
			
			iconCache = null;
			showToast("�ڴ治��activity�˳�");
			finish();
		}
		
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unregisterReceiver(receiver);
	}
	
}
