package cn.itcast.douban;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gdata.data.TextContent;
import com.google.gdata.data.douban.Attribute;
import com.google.gdata.data.douban.NoteEntry;
import com.google.gdata.data.douban.NoteFeed;
import com.google.gdata.data.douban.UserEntry;
import com.google.gdata.util.ServiceException;

import cn.itcast.douban.domain.Note;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyNoteActivity extends BaseActivity implements OnClickListener {
	private ListView subjectlist;
	private Button bt_next, bt_pre;
	private int startindex = 1;
	private int count = 10;
	private boolean isloading=false;
	ProgressDialog pd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		setContentView(R.layout.my_note);
		super.onCreate(savedInstanceState);
	}

	@Override
	public void setupView() {
		mRelativeLoading = (RelativeLayout) this.findViewById(R.id.loading);
		subjectlist = (ListView) this.findViewById(R.id.subjectlist);
	
		bt_next = (Button) this.findViewById(R.id.bt_next);
		bt_pre = (Button) this.findViewById(R.id.bt_pre);

	}

	@Override
	public void setListener() {
		bt_next.setOnClickListener(this);
		bt_pre.setOnClickListener(this);
//		subjectlist.setOnItemClickListener(new OnItemClickListener() {
//
//			public void onItemClick(AdapterView<?> parent, View view,
//					int position, long id) {
//				
//				
//			}
//		});
		registerForContextMenu(subjectlist);
		

	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
	                                ContextMenuInfo menuInfo) {
	  super.onCreateContextMenu(menu, v, menuInfo);
	  MenuInflater inflater = getMenuInflater();
	  inflater.inflate(R.menu.context_menu, menu);
	}
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
	  int position =  (int) info.id;
		Note note = (Note) subjectlist.getItemAtPosition(position);
		NoteEntry entry = note.getNoteEntry();
	  switch (item.getItemId()) {
	  case R.id.menu_add_note:
		    Intent intent = new Intent(this,NewNoteActivity.class);
		    startActivityForResult(intent, 0);
	        return true;
	  case R.id.menu_delete_note:
		  	deleteNote(entry);
		    return true;
	  case R.id.menu_edit_note:
			
		    return true;
	  }
	  return super.onContextItemSelected(item);
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode==200){
			startindex = 1;
			fillData();
		}
	}

	/**
	 * ɾ���ռ�
	 * @param entry
	 */
	private void deleteNote(NoteEntry entry) {
		new AsyncTask<NoteEntry, Void, Boolean>(){

			@Override
			protected Boolean doInBackground(NoteEntry... params) {
			 	try {
					myService.deleteNote( params[0]);
					return true;
				} catch (Exception e) {
					
					e.printStackTrace();
					return false;
				}
			
			}

			@Override
			protected void onPreExecute() {
				pd = new ProgressDialog(MyNoteActivity.this);
				pd.setMessage("����ɾ���ռ�");
				pd.show();
				super.onPreExecute();
			}

			@Override
			protected void onPostExecute(Boolean result) {
				pd.dismiss();
				if(result){
					fillData();
				}else{
					showToast("ɾ���ռ�ʧ��");
				}
				super.onPostExecute(result);
			}
			
			
		}.execute(entry);
		
	}

	@Override
	public void fillData() {
		if(isloading){
			showToast("��������������");
			return;
		}
		
		new AsyncTask<Void, Void, List<Note>>() {

			@Override
			protected void onPreExecute() {
				showLoading();
				isloading = true;
				super.onPreExecute();
			}

			@Override
			protected void onPostExecute(List<Note> result) {
				hideLoading();
				super.onPostExecute(result);
				if (result != null) {
					// ���õ���������������
					MyNoteAdapter adapter = new MyNoteAdapter(result);
					subjectlist.setAdapter(adapter);
				} else {
					showToast("�������ݷ����쳣");
				}
				isloading =false;
			}

			@Override
			protected List<Note> doInBackground(Void... params) {
				try {
					UserEntry ue = myService.getAuthorizedUser();
					String uid = ue.getUid();
					// ���Ȼ�ȡ�û��� �����ռ�����Ϣ
					NoteFeed noteFeed = myService.getUserNotes(uid, startindex,
							count);
					List<Note> notes = new ArrayList<Note>();
					for (NoteEntry ne : noteFeed.getEntries()) {
						Note note = new Note();
						note.setNoteEntry(ne);
						if (ne.getContent() != null)

							note.setContent(((TextContent) ne.getContent())
									.getContent().getPlainText());

						note.setTitle(ne.getTitle().getPlainText());

						for (Attribute attr : ne.getAttributes()) {

							if ("can_reply".equals(attr.getName())) {
								note.setCan_reply(attr.getContent());
							} else if ("privacy".equals(attr.getName())) {
								note.setCan_reply(attr.getContent());
							}
						}
						note.setPubdate(ne.getPublished().toString());
						notes.add(note);
					}
					return notes;
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}
		}.execute();

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_next:
			startindex+=count;
			if(startindex>100){
				showToast("����ȡ100��");
				return ;
			}
			fillData();
			break;

		case R.id.bt_pre:
			if(startindex>11){
				startindex=startindex-count;
				fillData();
			}else{
				showToast("�Ѿ������˵�һҳ");
			}
			break;
		}

	}

	private class MyNoteAdapter extends BaseAdapter {
		private List<Note> userNotes;

		public MyNoteAdapter(List<Note> userNotes) {
			this.userNotes = userNotes;
		}

		public int getCount() {
			// TODO Auto-generated method stub
			return userNotes.size();
		}

		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return userNotes.get(position);
		}

		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = null;
			if (convertView == null) {

				view = View.inflate(getApplicationContext(), R.layout.note_item, null);
			}else{
				view = convertView;
			}
			TextView tv = (TextView) view.findViewById(R.id.fav_title);
			tv.setText(userNotes.get(position).getTitle());
			return view;

		}

	}
}
