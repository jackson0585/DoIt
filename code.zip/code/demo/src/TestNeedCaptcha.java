import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.Source;



public class TestNeedCaptcha {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
		
		URL url = new URL("http://www.douban.com/accounts/login");
		
		 URLConnection  conn  = url.openConnection();
		 Source source = new Source(conn);
		 
		 List<Element> elements = source.getAllElements("input");
		 for(Element element : elements){
			   String result = element.getAttributeValue("name");
			   System.out.println(element.getAttributeValue("name"));
			   if("captcha-id".equals(result)){
				 	System.out.println("��Ҫ��֤��");
				 	System.out.println(element.getAttributeValue("value"));
				 	return ;
			   }
		 }
			System.out.println("����Ҫ��֤��");
	}

}
